<div class="container">
<nav class="row navbar navbar-expand-lg navbar-light bg-white">
<div class="navbar-nav ml-auto mr-auto mr-sm-auto mr-lg-0 mr-md-auto">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
    <img src="<?php echo e(url('frontend/images/logo.png')); ?>" alt="" />
    </a>
</div>
<ul class="navbar-nav mr-auto d-none d-lg-block">
    <li>
    <span class="text-muted"
        >| &nbsp; Beyond the explorer of the world</span
    >
    </li>
</ul>
</nav>
</div><?php /**PATH C:\laragon\www\nomads\resources\views/includes/navbar-alternate.blade.php ENDPATH**/ ?>