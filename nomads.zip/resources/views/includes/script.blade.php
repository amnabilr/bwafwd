<script src="{{ url('frontend/libraries/retina/retina.js')}}"></script>
<script src="{{ url('frontend/libraries/jquery/jquery-3.4.1.min.js')}}"></script>
<script src="{{ url('frontend/libraries/bootstrap/js/bootstrap.js')}}"></script>